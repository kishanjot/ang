import { Component, EventEmitter,Output} from '@angular/core';
import { Comment } from '../models/Comment';

@Component({
  selector: 'app-template-driven',
  templateUrl: './template-driven.component.html',
  styleUrls: ['./template-driven.component.css']
})
export class TemplateDrivenComponent {
  

postedComment: Comment
    constructor() 
    {

    this.postedComment={
      username:'',
      comment:''
    }
   }

log(val){
  console.log(val);
  }


submitForm(){

alert(JSON.stringify(this.postedComment));
  }

}
