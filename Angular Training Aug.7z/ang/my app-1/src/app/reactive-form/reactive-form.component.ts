import { Component} from '@angular/core';
import { FormGroup,FormBuilder, Validators} from "@angular/forms";

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent {
  rForm: FormGroup;
  constructor(private builder: FormBuilder){
    this.rForm=this.builder.group({
      'username' :['',Validators.required],
      'comment' :['',Validators.compose([Validators.required,Validators.minLength(10)])]
    });
  }
 submit(post:Comment)

 {
   alert(JSON.stringify(post))
 }
}
