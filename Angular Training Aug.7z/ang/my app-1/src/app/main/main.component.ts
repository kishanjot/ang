import { Component, OnInit } from '@angular/core';
import { Employee } from '../models/Employee';
@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent{

  title = 'my-app1';
  price: number = 200;
  path='assets/alert.jpg';
  // path1='assets/apple.png';
  classToUse='class2';
  applyBg :boolean=true;
  bgText:string='Remove Bg Color';

  hide: boolean =false;
  

  listStr: string[] =['value1','value2','value3','value4'];
  listEmp: Employee[] /* Employee is typesafety imported from models folder*/ =[
    {firstName : 'Kishanjot', lastName:'Singh', salary:9000},
    {firstName : 'Joy', lastName:'Jot', salary:1000},
    {firstName : 'Root', lastName:'Singh', salary:3000},
    {firstName : 'Kim', lastName:'Kar', salary:2000},
    {firstName : 'Brett', lastName:'Lee', salary:6000}
  ]
    getFullName(firstName,lastName):string{
      return `${firstName} ${lastName}`; /* Also String Interpolation*/

      // return firstName+' ' +lastName; 
    }

    buttonClicked()
    {
     // alert('Bomb Will Blast in 3..2..1.. BOOM');
     this.path=(this.path == 'assets/alert.jpg' )
                ?'assets/apple.png' : 'assets/alert.jpg';
    }

    bgChanged()
    {
      this.applyBg=(this.applyBg == true )
                ?false : true;

      this.bgText=(this.bgText == 'Remove Bg Color') 
                ?'Apply Bg Color' : 'Remove Bg Color';
    }
    
    showTable()
    {
      this.hide=!this.hide;
    }
    

}
