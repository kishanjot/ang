import { CalcAgePipe } from './calc-age.pipe';

describe('CalcAgePipe', () => {
  it('create an instance', () => {
    const pipe = new CalcAgePipe();
    expect(pipe).toBeTruthy();
  });
});
