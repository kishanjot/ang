import { Component} from '@angular/core';
import { validateConfig } from '@angular/router/src/config';

@Component({
  selector: 'app-two-way',
  templateUrl: './two-way.component.html',
  styleUrls: ['./two-way.component.css']
})
export class TwoWayComponent {

  val: string='Hello';
}
