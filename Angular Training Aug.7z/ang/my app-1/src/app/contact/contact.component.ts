import { Component, Input} from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent  {

@Input() firstName: string='Fname';
@Input()  lastName: string='Lname';
@Input()  email: string='xyz@domain.com';
@Input()  mobile: string='xxx-xxx-xxxx';


}
