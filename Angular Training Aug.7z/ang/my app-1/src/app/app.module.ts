import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';//ngmodel
import {HttpClientModule} from '@angular/common/http';
import {RouterModule ,Routes, PreloadAllModules, PreloadingStrategy} from '@angular/router';
import {MaterialModule} from './material/material.module';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { TwoWayComponent } from './two-way/two-way.component';
import { MainComponent } from './main/main.component';


import { ContactComponent } from './contact/contact.component';
import { ChildComponent } from './child/child.component';
import { ParentComponent } from './parent/parent.component';
import { Child2Component } from './child2/child2.component';
import { Child3Component } from './child3/child3.component';
import { TemplateDrivenComponent } from './template-driven/template-driven.component';
import { TemplateDrivenpComponent } from './template-drivenp/template-drivenp.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { PipeDemoComponentComponent } from './pipe-demo-component/pipe-demo-component.component';
import { SalaryTaxPipe } from './salary-tax.pipe';
import { CalcAgePipe } from './calc-age.pipe';
import { DirectiveDemoComponentComponent } from './directive-demo-component/directive-demo-component.component'; 


import { UserListComponent } from './user-list/user-list.component';
import { UserDetailsComponent } from './user-details/user-details.component';  //for observable service
import { FormRouteGuardService} from './form-route-guard.service';
import {LoginFormService} from './login-form.service';
import { LoginComponent } from './login/login.component';

const routes :Routes=[
  { path: 'users',component: UserListComponent},
  { path: 'users/:id',component: UserDetailsComponent},
  { path: 'rform',component: ReactiveFormComponent,canDeactivate:[FormRouteGuardService]}, 
  { path: 'tdform',component: TemplateDrivenComponent,canActivate:[LoginFormService]},
  { path: '',redirectTo:'/users', pathMatch:'full'},  //full for full address that'll include local host
  { path: 'comp1', loadChildren:'./lazyloading/lazyloading.module#LazyloadingModule'}, // after # its class name of that module
  { path: '**',component: DirectiveDemoComponentComponent}, //home page

];

// routing 
@NgModule({
  declarations: [
    AppComponent,
    TwoWayComponent,
    MainComponent,
    ContactComponent,
    ChildComponent,
    ParentComponent,
    Child2Component,
    Child3Component,
    TemplateDrivenComponent,
    TemplateDrivenpComponent,
    ReactiveFormComponent,
    PipeDemoComponentComponent,
    SalaryTaxPipe,
    CalcAgePipe,
    DirectiveDemoComponentComponent,
    UserListComponent,
    UserDetailsComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, //For ngmodel
    ReactiveFormsModule,
    HttpClientModule, //obs services
    RouterModule.forRoot(routes, {preloadingStrategy:PreloadAllModules}), //for routing
    MaterialModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
