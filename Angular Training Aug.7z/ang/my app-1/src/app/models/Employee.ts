export interface Employee
{
    firstName : string;
    lastName? : string;
    salary : number;
    doj?: string;
    dob?:string;

}