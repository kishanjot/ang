import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import {ReactiveFormComponent} from './reactive-form/reactive-form.component'
@Injectable({
  providedIn: 'root'
})
export class FormRouteGuardService implements CanDeactivate<ReactiveFormComponent> //candeactivate for that popoup.s

{

  constructor() { }
  canDeactivate(form : ReactiveFormComponent){
    if(form.rForm.dirty)
    return confirm('Are you sure you want to leave this page?');
    else
    return true;

  }
  
}
