import { Component } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent  {

// msg :string;

// getMessage(value:string){
// this.msg=value;
// }

// values: number[]; 
//   constructor(){
//     this.values = [];
//   }
//   getValues(num){
//     this.values.push(num);
//   }
// for numbers ^


//for string
values: string[]=[];
constructor(){
  this.values = [];
}
getValues(str){
  this.values.push(str);
}
}
