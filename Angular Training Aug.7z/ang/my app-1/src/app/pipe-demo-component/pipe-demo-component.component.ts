import { Component } from '@angular/core';
import { Employee } from '../models/Employee';

@Component({
  selector: 'app-pipe-demo-component',
  templateUrl: './pipe-demo-component.component.html',
  styleUrls: ['./pipe-demo-component.component.css']
})
export class PipeDemoComponentComponent  {

  empList : Employee[];
  constructor() {
    this.empList = [
      {firstName:'Kishanjot',lastName:'Singh',salary:12000,doj:'2017-08-19',dob:'1991-08-07'},
      {firstName:'Joseph',lastName:'murphy',salary:11000,doj:'2018-04-28',dob:'2001-05-14'},
      {firstName:'Gerry',lastName:'Cramer',salary:15000,doj:'2019-01-15',dob:'1987-12-24'},
      
    ] //here we are giving array, so give syntax like array = [{},{}]
   }

  
}
