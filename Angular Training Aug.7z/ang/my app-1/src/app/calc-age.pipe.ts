import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
  name: 'calcAge'
})
export class CalcAgePipe implements PipeTransform {
  timeDiff: number=0;
  age: number=0;


  transform(dob: String, args?: number): number {
return;

    //  this.timeDiff = Math.abs(new Date() - new Date(dob));
    //    
    //     this.age = Math.floor((this.timeDiff / (1000 * 3600 * 24))/365);
    
    //     return this.age;
  }
}


 
