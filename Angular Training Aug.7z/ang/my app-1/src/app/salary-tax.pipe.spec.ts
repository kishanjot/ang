import { SalaryTaxPipe } from './salary-tax.pipe';

describe('SalaryTaxPipe', () => {
  it('create an instance', () => {
    const pipe = new SalaryTaxPipe();
    expect(pipe).toBeTruthy();
  });
});
