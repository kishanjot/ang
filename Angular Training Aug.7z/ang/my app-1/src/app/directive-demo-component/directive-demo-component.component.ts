import { Component} from '@angular/core';
import { SampleService } from '../sample.service'; //service

@Component({
  selector: 'app-directive-demo-component',
  templateUrl: './directive-demo-component.component.html',
  styleUrls: ['./directive-demo-component.component.css']
})
export class DirectiveDemoComponentComponent {
 
  msg:string; //service

  isStructuralVisible :boolean=false;
  isAttributeHidden  :boolean=true;

  btn1Text:string;
  btn2Text:string;
constructor(private service: SampleService)
{
  this.btn1Text='Show';
  this.btn2Text='Show';
  this.msg=this.service.greet("Kishan");
}

  showStructural(){
    this.isStructuralVisible=!this.isStructuralVisible;
    this.btn1Text=this.isStructuralVisible?'Hide' : 'Show';
  }
  showAttribute(){
    this.isAttributeHidden=!this.isAttributeHidden;
    this.btn2Text=this.isAttributeHidden?'Show' : 'Hide';
  }
}
