import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DirectiveDemoComponentComponent } from './directive-demo-component.component';

describe('DirectiveDemoComponentComponent', () => {
  let component: DirectiveDemoComponentComponent;
  let fixture: ComponentFixture<DirectiveDemoComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DirectiveDemoComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DirectiveDemoComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
