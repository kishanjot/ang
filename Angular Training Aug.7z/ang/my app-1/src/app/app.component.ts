import { Component } from '@angular/core';
import { Employee } from './models/Employee';
import { HighlightDelayBarrier } from 'blocking-proxy/built/lib/highlight_delay_barrier';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
    message: string;

    getMessage(value:string){
      this.message=value;
    }

}
