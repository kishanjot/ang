import { Component, OnInit } from '@angular/core';
import {DataService} from '../data.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
  user={};
  id=0;
  constructor(private service: DataService,
              private route: ActivatedRoute) { }

  ngOnInit() {
    this.id=this.route.snapshot.params['id'];
    this.service.getUserById(this.id).subscribe(u=>
      {
      this.user=u;
  //   console.log(this.id,this.user);  
    })
  }

}
