import { Component,EventEmitter,Output} from '@angular/core';

@Component({
  selector: 'app-child2',
  templateUrl: './child2.component.html',
  styleUrls: ['./child2.component.css']
})
export class Child2Component {

  // 
  // @Output() addEvent=new EventEmitter<number>();

  // sendMessage()
  // {
  //   this.messageEvent.emit('Message sent by Child A to Child B via Parent');
  // }

  // num:number;
  // constructor(){
  //   this.addEvent=new EventEmitter<number>();
  //   this.num=1;
  // }

  // addValues(){
  //   this.addEvent.emit(this.num);
  //   this.num++;
  // }
  

  @Output() addEvent=new EventEmitter<string>();
  str: string;
  constructor(){
      this.addEvent=new EventEmitter<string>();
     
     }

     addValues(){
        this.addEvent.emit(this.str);
        
       }
}
