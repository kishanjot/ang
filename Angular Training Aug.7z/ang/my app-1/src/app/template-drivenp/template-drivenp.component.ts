import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-drivenp',
  templateUrl: './template-drivenp.component.html',
  styleUrls: ['./template-drivenp.component.css']
})
export class TemplateDrivenpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
