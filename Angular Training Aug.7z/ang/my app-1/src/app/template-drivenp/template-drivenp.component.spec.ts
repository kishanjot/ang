import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateDrivenpComponent } from './template-drivenp.component';

describe('TemplateDrivenpComponent', () => {
  let component: TemplateDrivenpComponent;
  let fixture: ComponentFixture<TemplateDrivenpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateDrivenpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateDrivenpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
