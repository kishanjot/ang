import { TestBed } from '@angular/core/testing';

import { FormRouteGuardService } from './form-route-guard.service';

describe('FormRouteGuardService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FormRouteGuardService = TestBed.get(FormRouteGuardService);
    expect(service).toBeTruthy();
  });
});
