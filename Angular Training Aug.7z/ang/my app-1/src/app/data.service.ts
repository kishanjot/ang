import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
 path :string='http://jsonplaceholder.typicode.com/';
  constructor(private http:HttpClient) { }

  getUsers():Observable<any>{
    return this.http.get(this.path + 'users');
  }

  
  getUserById(id):Observable<any>{
    console.log('service'+id);
    return this.http.get(this.path + 'users/' +id);
  }

  
  addUser(user):Observable<any>{
    return this.http.post(this.path + 'users/', user);
  }

  
  updateUser(user):Observable<any>{
    return this.http.put(this.path + 'users/' ,user);
  }

  
}
