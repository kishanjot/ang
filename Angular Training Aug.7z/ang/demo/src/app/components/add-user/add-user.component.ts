import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent {
  username: string;
  @Output() sendUserEvent: EventEmitter<string>;
  constructor(){
    this.username = '';
    this.sendUserEvent = new EventEmitter<string>();
  }
  addUser(){
    this.sendUserEvent.emit(this.username);
  }
}
