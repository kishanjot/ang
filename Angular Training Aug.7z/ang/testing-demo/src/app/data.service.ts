import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() { }
  greet(name : string){
    return 'Hey ' + name;
    }
  
    checkUserName(name){
      if(name === 'XXX')
      {
      return false;
      }
      else {
      return true;
      }
    }
  
}
