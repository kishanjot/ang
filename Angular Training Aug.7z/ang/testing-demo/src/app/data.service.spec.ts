import { TestBed } from '@angular/core/testing';

import { DataService } from './data.service';

describe('DataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DataService = TestBed.get(DataService);
    expect(service).toBeTruthy();
  });

  it('greet function should return Hello Kishan when Hey Kishan is passed', () => {
    const service: DataService = TestBed.get(DataService);
    expect(service.greet('Kishan')).toEqual('Hey Kishan');
  });

  it('should get failed if username XXX is passed', () => {
    const service: DataService = TestBed.get(DataService);
    expect(service.checkUserName('XXX')).toBeFalsy();
  });


});
