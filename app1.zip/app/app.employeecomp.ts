import {Component} from '@angular/core';

@Component({
     selector:'emp-loyee',
     templateUrl:'app.employee.html'

})

export class EmployeeComp{

}