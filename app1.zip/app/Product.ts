export class Product
{
    prodId:Number;
    prodName:String;
    prodPrice:Number;
    prodOnline:boolean;
}