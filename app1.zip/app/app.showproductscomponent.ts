import{Component} from '@angular/core';

@Component({
     selector:'show-prod',
     templateUrl:'app.show.html'

})

export class ShowProduct{
    
}