import {Component} from '@angular/core';
import {Product} from './Product';
@Component({
     selector:'add-prod',
     templateUrl:'app.product.html'

})

export class AddProduct{

     // prodId:number; 
     // prodName:string=""; 
     // prodPrice:number; 
     // prodOnline:boolean;
     // prod:Product={prodId:1001,prodName:"ABC",prodPrice:5000,prodOnline:true};

     // getAllEmployee():any{
     //      alert("Hello Done");
     // }

     // getProductDetails():any{
     //      alert("Product Details at XZC");
     // }

     // prod:Product={
     //      prodId:0,prodName:"",prodPrice:0.0,prodOnline:true
     // };

     prod:any={};
     prodAll:Product[]=[
          {prodId:1001,prodName:"Rice",prodPrice:89.69,prodOnline:true},
          {prodId:1002,prodName:"wheat",prodPrice:189.69,prodOnline:true},
          {prodId:1003,prodName:"jawar",prodPrice:289.69,prodOnline:true},
          {prodId:1004,prodName:"bajra",prodPrice:389.69,prodOnline:true},
          {prodId:1005,prodName:"apple",prodPrice:489.69,prodOnline:true},
     ];


     addProduct():any{
          this.prodAll.push(this.prod);
          this.prod={};
     }


     
     // getDetails():any{
     //      alert("Welcome to DOM to COmponent");
     //  }
     // addProduct():any{
     //      alert(this.prodId+" "+this.prodName+" "+this.prodPrice+" "+this.prodOnline);
     // }

     
      getProductDetails():any{
          alert(this.prod.prodId+" "+this.prod.prodName+" "+this.prod.prodPrice+" "+this.prod.prodOnline);
     }

     deleteProduct(i:number):any{
          this.prodAll.splice(i,1);
          alert("Product"+" "+i+" "+"Deleted Succesfully!!");
      }


          updateProduct():any{ 
          }  


}